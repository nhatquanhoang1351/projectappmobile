package com.example.quanlykhosua.data;

public class Payment {
    private int id;
    private int productId;
    private String content;
    private int quantity;
    private String date;
    private double price;

    // Constructor
    public Payment(int id, int productId, String content, int quantity, String date, double price) {
        this.id = id;
        this.productId = productId;
        this.content = content;
        this.quantity = quantity;
        this.date = date;
        this.price = price;
    }

    // Getters
    public int getId() {
        return id;
    }

    public int getProductId() {
        return productId;
    }

    public String getContent() {
        return content;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDate() {
        return date;
    }

    public double getPrice() {
        return price;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public android.content.ContentValues toContentValues() {
        android.content.ContentValues values = new android.content.ContentValues();
        values.put("id_san_pham", productId);
        values.put("noi_dung", content);
        values.put("so_luong", quantity);
        values.put("ngay_gio", date);
        values.put("gia", price);
        return values;
    }
}
