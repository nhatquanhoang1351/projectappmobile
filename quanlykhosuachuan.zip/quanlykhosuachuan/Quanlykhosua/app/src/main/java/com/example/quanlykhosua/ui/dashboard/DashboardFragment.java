package com.example.quanlykhosua.ui.dashboard;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardFragment extends Fragment {
    private DatabaseHelper dbHelper;
    private TableLayout tableLayout;
    private int selectedProductId = -1;
    private String selectedProductCode = "";
    private String selectedProductName = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        dbHelper = new DatabaseHelper(getContext());

        tableLayout = root.findViewById(R.id.tableLayout);
        Button btnNhapHang = root.findViewById(R.id.btnNhapHang);
        Button btnXuatHang = root.findViewById(R.id.btnXuatHang);

        loadData();

        btnNhapHang.setOnClickListener(v -> {
            if (selectedProductId != -1) {
                showAddPaymentDialog(selectedProductId, selectedProductCode, selectedProductName, "1");
            } else {
                Toast.makeText(getContext(), "Vui lòng chọn sản phẩm để nhập hàng", Toast.LENGTH_SHORT).show();
            }
        });

        btnXuatHang.setOnClickListener(v -> {
            if (selectedProductId != -1) {
                showAddPaymentDialog(selectedProductId, selectedProductCode, selectedProductName, "2");
            } else {
                Toast.makeText(getContext(), "Vui lòng chọn sản phẩm để xuất hàng", Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    private void loadData() {
        tableLayout.removeAllViews();
        selectedProductId = -1;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_PRODUCT, null, null, null, null, null, null);

        TableRow header = new TableRow(getContext());
        header.addView(createTextView("Mã SP"));
        header.addView(createTextView("Tên Sản Phẩm"));
        header.addView(createTextView("Số Lượng"));
        tableLayout.addView(header);

        while (cursor.moveToNext()) {
            final int productId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            final String productCode = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CODE));
            final String productName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));

            TableRow row = new TableRow(getContext());
            row.addView(createTextView(productCode));
            row.addView(createTextView(productName));
            row.addView(createTextView(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY)))));

            row.setOnClickListener(v -> {
                for (int i = 1; i < tableLayout.getChildCount(); i++) {
                    tableLayout.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.transparent));
                }

                v.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                selectedProductId = productId;
                selectedProductCode = productCode;
                selectedProductName = productName;
            });

            tableLayout.addView(row);
        }
        cursor.close();
    }

    private void showAddPaymentDialog(int productId, String productCode, String productName, String loaiGiaoDich) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_payment, null);

        EditText etMaSP = dialogView.findViewById(R.id.etMaSP);
        EditText etTenSP = dialogView.findViewById(R.id.etTenSP);
        EditText etSoLuong = dialogView.findViewById(R.id.etSoLuong);
        EditText etGia = dialogView.findViewById(R.id.etGia);

        etMaSP.setText(productCode);
        etTenSP.setText(productName);
        etMaSP.setEnabled(false);
        etTenSP.setEnabled(false);

        builder.setTitle(loaiGiaoDich.equals("1") ? "Nhập Hàng" : "Xuất Hàng")
                .setView(dialogView)
                .setPositiveButton("Xác Nhận", (dialog, which) -> {
                    String soLuongStr = etSoLuong.getText().toString();
                    String giaStr = etGia.getText().toString();
                    if (!soLuongStr.isEmpty() && !giaStr.isEmpty()) {
                        int soLuong = Integer.parseInt(soLuongStr);
                        double gia = Double.parseDouble(giaStr);
                        addPayment(productId, loaiGiaoDich, soLuong, gia);
                    } else {
                        Toast.makeText(getContext(), "Vui lòng nhập số lượng và giá", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void addPayment(int productId, String loaiGiaoDich, int quantity, double gia) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentTime = dateFormat.format(new Date());

        db.execSQL("INSERT INTO " + DatabaseHelper.TABLE_PAYMENT +
                        " (id_san_pham, noi_dung, so_luong, ngay_gio, gia) VALUES (?, ?, ?, ?, ?)",
                new Object[]{productId, loaiGiaoDich, quantity, currentTime, gia});

        if (loaiGiaoDich.equals("1")) {
            db.execSQL("UPDATE " + DatabaseHelper.TABLE_PRODUCT +
                            " SET so_luong = so_luong + ? WHERE id = ?",
                    new Object[]{quantity, productId});
        } else {
            db.execSQL("UPDATE " + DatabaseHelper.TABLE_PRODUCT +
                            " SET so_luong = so_luong - ? WHERE id = ?",
                    new Object[]{quantity, productId});
        }

        loadData();

        Toast.makeText(getContext(),
                loaiGiaoDich.equals("1") ? "Nhập hàng thành công" : "Xuất hàng thành công",
                Toast.LENGTH_SHORT).show();
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(getContext());
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        return textView;
    }
}