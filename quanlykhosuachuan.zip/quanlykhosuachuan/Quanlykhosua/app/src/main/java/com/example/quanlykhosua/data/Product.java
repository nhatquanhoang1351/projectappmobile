package com.example.quanlykhosua.data;

public class Product {
    private int id;
    private String productCode;
    private String name;
    private int quantity;
    private String unit;
    private String warehouse;
    public Product(int id, String productCode, String name, int quantity, String unit, String warehouse) {
        this.id = id;
        this.productCode = productCode;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.warehouse = warehouse;
    }

    // Getters
    public int getId() {
        return id;
    }
    public String getProductCode() {
        return productCode;
    }
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getUnit() {
        return unit;
    }

    public String getWarehouse() {
        return warehouse;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }
    public android.content.ContentValues toContentValues() {
        android.content.ContentValues values = new android.content.ContentValues();
        values.put(DatabaseHelper.COLUMN_CODE, productCode);
        values.put(DatabaseHelper.COLUMN_NAME, name);
        values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
        values.put(DatabaseHelper.COLUMN_UNIT, unit);
        values.put(DatabaseHelper.COLUMN_WAREHOUSE, warehouse);
        return values;
    }
}
