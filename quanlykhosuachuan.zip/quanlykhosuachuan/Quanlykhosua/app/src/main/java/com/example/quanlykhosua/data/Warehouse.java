package com.example.quanlykhosua.data;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Warehouse {
    private int id;
    private String name;
    private String address;
    private List<String> milkAvailable;

    public Warehouse(int id, String name, String address, List<String> milkAvailable) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.milkAvailable = milkAvailable;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public List<String> getMilkAvailable(Context context) {
        List<String> productNames = new ArrayList<>();
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        SQLiteDatabase db = null;

        try {
            db = dbHelper.getReadableDatabase();

            String query = "SELECT " + DatabaseHelper.COLUMN_NAME + " FROM " +
                    DatabaseHelper.TABLE_PRODUCT + " WHERE " +
                    DatabaseHelper.COLUMN_WAREHOUSE + " = ?";

            Cursor cursor = db.rawQuery(query, new String[]{this.name});

            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
                if (columnIndex != -1) {
                    do {
                        String productName = cursor.getString(columnIndex);
                        productNames.add(productName);
                    } while (cursor.moveToNext());
                }
                cursor.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return productNames;
    }
    public android.content.ContentValues toContentValues() {
        android.content.ContentValues values = new android.content.ContentValues();
        values.put(DatabaseHelper.COLUMN_WAREHOUSE_NAME, name);
        values.put(DatabaseHelper.COLUMN_WAREHOUSE_LOCATION, address);
        return values;
    }
}
