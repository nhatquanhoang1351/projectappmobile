package com.example.quanlykhosua.ui.home;

import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.data.Product;
import com.example.quanlykhosua.data.Warehouse;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class WarehouseAdapter extends RecyclerView.Adapter<WarehouseAdapter.WarehouseViewHolder> {
    private List<Warehouse> warehouselist;
    private Context context;
    private DatabaseHelper databaseHelper;
    public WarehouseAdapter(List<Warehouse> warehouselist, Context context, DatabaseHelper databaseHelper) {

        this.warehouselist = warehouselist;
        this.context = context;
        this.databaseHelper = databaseHelper;

    }

    @Override
    public WarehouseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_warehouse, parent, false);
        return new WarehouseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(WarehouseViewHolder holder, int position) {
        Warehouse warehouse = warehouselist.get(position);
        holder.tvWarehouseName.setText(warehouse.getName());
        holder.tvWarehouseAddress.setText(String.valueOf(warehouse.getAddress()));
        List<String> milkAvailableProducts = warehouse.getMilkAvailable(holder.itemView.getContext());
        if (!milkAvailableProducts.isEmpty()) {
            StringBuilder milkProducts = new StringBuilder();
            for (String product : milkAvailableProducts) {
                milkProducts.append(product).append("\n");
            }
            holder.tvMilkAvailable.setText(milkProducts.toString());
        } else {
            holder.tvMilkAvailable.setText("No milk available");
        }
        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(warehouse));
    }
    private void showDeleteDialog(Warehouse warehouse) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Bạn có chắc chắn muốn xóa kho này?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    SQLiteDatabase db = databaseHelper.getWritableDatabase();
                    db.delete(DatabaseHelper.TABLE_WAREHOUSE, DatabaseHelper.COLUMN_ID + "=?",
                            new String[]{String.valueOf(warehouse.getId())});
                    warehouselist.remove(warehouse);
                    notifyDataSetChanged();
                    Toast.makeText(context, "Xóa kho thành công!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss())
                .show();
    }
    @Override
    public int getItemCount() {
        return warehouselist.size();
    }

    public static class WarehouseViewHolder extends RecyclerView.ViewHolder {
        TextView tvWarehouseName, tvWarehouseAddress, tvMilkAvailable;
        FloatingActionButton btnDelete;
        public WarehouseViewHolder(View itemView) {
            super(itemView);
            tvWarehouseName = itemView.findViewById(R.id.tenkho);
            tvWarehouseAddress = itemView.findViewById(R.id.diachikho);
            tvMilkAvailable = itemView.findViewById(R.id.suahienco);
            btnDelete = itemView.findViewById(R.id.deleteButton);
        }
    }
}
