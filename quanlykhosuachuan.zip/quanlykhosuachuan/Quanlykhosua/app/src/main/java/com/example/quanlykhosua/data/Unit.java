package com.example.quanlykhosua.data;

public class Unit {
    private String name;
    private String description;

    public Unit(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
