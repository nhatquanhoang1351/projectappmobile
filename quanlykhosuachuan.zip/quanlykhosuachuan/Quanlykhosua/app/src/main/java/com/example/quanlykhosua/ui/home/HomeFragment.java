package com.example.quanlykhosua.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.Unit;
import com.example.quanlykhosua.ui.unit.UnitFragment;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private UnitAdapter unitAdapter;
    private List<Unit> unitList;
    private ImageView imageViewUnit, imageViewMilk, imageViewWareHouse, imageViewCost;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = root.findViewById(R.id.unitRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        imageViewUnit = root.findViewById(R.id.imageViewUnit);
        imageViewUnit.setOnClickListener(v -> openUnitFragment());

        imageViewMilk = root.findViewById(R.id.imageViewMilk);
        imageViewMilk.setOnClickListener(v -> openMilkFragment());

        imageViewWareHouse = root.findViewById(R.id.imageViewWareHouse);
        imageViewWareHouse.setOnClickListener(v -> openWareHouseFragment());

        imageViewCost = root.findViewById(R.id.imageViewCost);
        imageViewCost.setOnClickListener(v -> openCostFragment());
        return root;
    }

    private void openMilkFragment() {
        NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_activity_main);
        navController.navigate(R.id.action_navigation_home_to_milkFragment);
    }


    private void openUnitFragment() {
        NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_activity_main);
        navController.navigate(R.id.action_navigation_home_to_unitFragment);
    }
    private void openWareHouseFragment() {
        NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_activity_main);
        navController.navigate(R.id.action_navigation_home_to_warehouseFragment);
    }
    private void openCostFragment() {
        NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_activity_main);
        navController.navigate(R.id.action_navigation_home_to_costFragment);
    }
}
