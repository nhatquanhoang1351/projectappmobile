package com.example.quanlykhosua.ui.unit;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.data.Unit;
import com.example.quanlykhosua.ui.home.UnitAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class UnitFragment extends Fragment {
    private RecyclerView recyclerView;
    private UnitAdapter unitAdapter;
    private List<Unit> unitList;
    private DatabaseHelper databaseHelper;
    private FloatingActionButton btnThemDonVi;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.unit, container, false);

        recyclerView = root.findViewById(R.id.unitRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        btnThemDonVi = root.findViewById(R.id.btnThemDonVi);
        btnThemDonVi.setOnClickListener(v -> showAddUnitDialog());

        databaseHelper = new DatabaseHelper(getContext());
        loadUnitData();

        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.action_unit_to_home);
                return true;
            }
            return false;
        });

        return root;
    }

    private void showAddUnitDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_unit, null);
        EditText etTenDonVi = dialogView.findViewById(R.id.etTenDonVi);
        EditText etMoTaDonVi = dialogView.findViewById(R.id.etMoTaDonVi);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(dialogView)
                .setTitle("Thêm Đơn Vị")
                .setPositiveButton("Thêm", (dialog, which) -> {
                    String tenDonVi = etTenDonVi.getText().toString().trim();
                    String moTaDonVi = etMoTaDonVi.getText().toString().trim();

                    if (tenDonVi.isEmpty()) {
                        Toast.makeText(getContext(), "Vui lòng nhập tên đơn vị!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Thêm đơn vị vào cơ sở dữ liệu
                    SQLiteDatabase db = databaseHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put(DatabaseHelper.COLUMN_UNIT_NAME, tenDonVi);
                    values.put(DatabaseHelper.COLUMN_UNIT_DESCRIPTION, moTaDonVi);

                    long result = db.insert(DatabaseHelper.TABLE_UNIT, null, values);

                    if (result != -1) {
                        Toast.makeText(getContext(), "Thêm đơn vị thành công!", Toast.LENGTH_SHORT).show();
                        loadUnitData(); // Cập nhật lại danh sách đơn vị
                    } else {
                        Toast.makeText(getContext(), "Thêm đơn vị thất bại!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void loadUnitData() {
        unitList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_UNIT,
                new String[]{DatabaseHelper.COLUMN_UNIT_ID, DatabaseHelper.COLUMN_UNIT_NAME, DatabaseHelper.COLUMN_UNIT_DESCRIPTION},
                null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UNIT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UNIT_NAME));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UNIT_DESCRIPTION));
                unitList.add(new Unit(name, description));
            }
            cursor.close();
        }

        unitAdapter = new UnitAdapter(unitList);
        recyclerView.setAdapter(unitAdapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
