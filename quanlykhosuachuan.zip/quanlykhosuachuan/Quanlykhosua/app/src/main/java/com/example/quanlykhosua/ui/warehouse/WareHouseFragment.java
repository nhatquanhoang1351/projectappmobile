package com.example.quanlykhosua.ui.warehouse;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.data.Warehouse;
import com.example.quanlykhosua.ui.home.WarehouseAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class WareHouseFragment extends Fragment {
    private RecyclerView recyclerView;
    private WarehouseAdapter warehouseAdapter;
    private List<Warehouse> warehouseList;
    private DatabaseHelper databaseHelper;
    private FloatingActionButton btnAddWareHouse;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        View root = inflater.inflate(R.layout.warehouse_fragment, container, false);
        recyclerView = root.findViewById(R.id.warehouseRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        databaseHelper = new DatabaseHelper(getContext());
        btnAddWareHouse = root.findViewById(R.id.btnThemKho);
        btnAddWareHouse.setOnClickListener(v -> showAddWareHouseDialog());
        loadWareHouseData();

        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.action_warehouse_to_home);
                return true;
            }
            return false;
        });
        return root;
    }

    private void showAddWareHouseDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_warehouse, null);
        builder.setView(dialogView);

        EditText edtName = dialogView.findViewById(R.id.etTenKho);
        EditText edtAddress = dialogView.findViewById(R.id.etDiachi);

        builder.setPositiveButton("Thêm", (dialog, which) -> {
            String name = edtName.getText().toString();
            String address = edtAddress.getText().toString();

            if (!name.isEmpty() && !address.isEmpty()) {
                SQLiteDatabase db = databaseHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_WAREHOUSE_NAME, name);
                values.put(DatabaseHelper.COLUMN_WAREHOUSE_LOCATION, address);
                long result = db.insert(DatabaseHelper.TABLE_WAREHOUSE, null, values);

                if (result != -1) {
                    Toast.makeText(getContext(), "Thêm kho thành công", Toast.LENGTH_SHORT).show();
                    loadWareHouseData(); // Reload data after adding
                } else {
                    Toast.makeText(getContext(), "Thêm kho thất bại", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void loadWareHouseData() {
        warehouseList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_WAREHOUSE,
                new String[]{DatabaseHelper.COLUMN_WAREHOUSE_ID, DatabaseHelper.COLUMN_WAREHOUSE_NAME, DatabaseHelper.COLUMN_WAREHOUSE_LOCATION},
                null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WAREHOUSE_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WAREHOUSE_NAME));
                String address = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WAREHOUSE_LOCATION));

                // Lấy danh sách milkAvailable
                List<String> milkAvailable = new ArrayList<>();
                Cursor milkCursor = db.query(DatabaseHelper.TABLE_PRODUCT,
                        new String[]{DatabaseHelper.COLUMN_NAME},
                        DatabaseHelper.COLUMN_WAREHOUSE_ID + "=?",
                        new String[]{String.valueOf(id)},
                        null, null, null);

                if (milkCursor != null) {
                    while (milkCursor.moveToNext()) {
                        milkAvailable.add(milkCursor.getString(milkCursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME)));
                    }
                    milkCursor.close();
                }

                Warehouse warehouse = new Warehouse(id, name, address, milkAvailable);
                warehouseList.add(warehouse);
            }
            cursor.close();
        }

        warehouseAdapter = new WarehouseAdapter(warehouseList, getContext(), databaseHelper);
        recyclerView.setAdapter(warehouseAdapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
