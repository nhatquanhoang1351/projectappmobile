package com.example.quanlykhosua.ui.home;

import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.data.Product;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private List<Product> productList;
    private Context context;
    private DatabaseHelper databaseHelper;

    public ProductAdapter(List<Product> productList, Context context, DatabaseHelper databaseHelper) {
        this.productList = productList;
        this.context = context;
        this.databaseHelper = databaseHelper;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_milk, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.tvProductName.setText(product.getName());
        holder.tvProductQuantity.setText(String.valueOf(product.getQuantity()));
        holder.tvProductUnit.setText(product.getUnit());
        holder.tvProductWarehouse.setText(product.getWarehouse());

        holder.btnEdit.setOnClickListener(v -> showEditDialog(product));
        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(product));
    }

    private void showEditDialog(Product product) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_poduct, null);
        TextView etProductCode = dialogView.findViewById(R.id.etMaSP);
        TextView etProductName = dialogView.findViewById(R.id.etTenSP);
        TextView etProductQuantity = dialogView.findViewById(R.id.etSoLuong);
        TextView etProductUnit = dialogView.findViewById(R.id.spDonVi);
        TextView etProductWarehouse = dialogView.findViewById(R.id.etKho);

        etProductCode.setText(product.getProductCode());
        etProductName.setText(product.getName());
        etProductQuantity.setText(String.valueOf(product.getQuantity()));
        etProductUnit.setText(product.getUnit());
        etProductWarehouse.setText(product.getWarehouse());

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(dialogView)
                .setTitle("Sửa Sản Phẩm")
                .setPositiveButton("Lưu", (dialog, which) -> {
                    product.setName(etProductName.getText().toString().trim());
                    product.setQuantity(Integer.parseInt(etProductQuantity.getText().toString().trim()));
                    product.setWarehouse(etProductWarehouse.getText().toString().trim());

                    SQLiteDatabase db = databaseHelper.getWritableDatabase();
                    db.update(DatabaseHelper.TABLE_PRODUCT, product.toContentValues(),
                            DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(product.getId())});
                    notifyDataSetChanged();
                    Toast.makeText(context, "Cập nhật sản phẩm thành công!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss())
                .show();
    }
    private void showDeleteDialog(Product product) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Bạn có chắc chắn muốn xóa sản phẩm này?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    SQLiteDatabase db = databaseHelper.getWritableDatabase();
                    db.delete(DatabaseHelper.TABLE_PRODUCT, DatabaseHelper.COLUMN_ID + "=?",
                            new String[]{String.valueOf(product.getId())});
                    productList.remove(product);
                    notifyDataSetChanged();
                    Toast.makeText(context, "Xóa sản phẩm thành công!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss())
                .show();
    }
    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView tvProductName, tvProductQuantity, tvProductUnit, tvProductWarehouse;
        FloatingActionButton btnEdit, btnDelete;
        public ProductViewHolder(View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.milkName);
            tvProductQuantity = itemView.findViewById(R.id.soluongmilk);
            tvProductUnit = itemView.findViewById(R.id.donvi);
            tvProductWarehouse = itemView.findViewById(R.id.kho);
            btnEdit = itemView.findViewById(R.id.editButton);
            btnDelete = itemView.findViewById(R.id.deleteButton);
        }
    }
}
