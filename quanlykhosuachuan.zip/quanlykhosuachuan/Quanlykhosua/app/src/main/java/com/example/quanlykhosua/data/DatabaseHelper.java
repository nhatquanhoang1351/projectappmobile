package com.example.quanlykhosua.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Warehouse.db";
    private static final int DATABASE_VERSION = 3;
    public static final String TABLE_PRODUCT = "product";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CODE = "ma_san_pham";
    public static final String COLUMN_NAME = "ten_san_pham";
    public static final String COLUMN_QUANTITY = "so_luong";
    public static final String COLUMN_UNIT = "don_vi";
    public static final String COLUMN_WAREHOUSE = "kho";

    public static final String TABLE_PAYMENT = "payment";
    public static final String COLUMN_PAYMENT_ID = "id";
    public static final String COLUMN_PRODUCT_ID = "id_san_pham";
    public static final String COLUMN_CONTENT = "noi_dung";
    public static final String COLUMN_PAYMENT_QUANTITY = "so_luong";
    public static final String COLUMN_DATE = "ngay_gio";
    public static final String COLUMN_PRICE = "gia";

    public static final String TABLE_UNIT = "unit";
    public static final String COLUMN_UNIT_ID = "id";
    public static final String COLUMN_UNIT_NAME = "ten_don_vi";
    public static final String COLUMN_UNIT_DESCRIPTION = "mo_ta";

    public static final String TABLE_WAREHOUSE = "warehouse";
    public static final String COLUMN_WAREHOUSE_ID = "id";
    public static final String COLUMN_WAREHOUSE_NAME = "ten_kho";
    public static final String COLUMN_WAREHOUSE_LOCATION = "vi_tri";

    private static final String CREATE_TABLE_PRODUCT =
            "CREATE TABLE " + TABLE_PRODUCT + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_CODE + " TEXT NOT NULL, " +
                    COLUMN_NAME + " TEXT NOT NULL, " +
                    COLUMN_QUANTITY + " INTEGER NOT NULL, " +
                    COLUMN_UNIT + " TEXT, " +
                    COLUMN_WAREHOUSE + " TEXT);";

    private static final String CREATE_TABLE_PAYMENT =
            "CREATE TABLE " + TABLE_PAYMENT + " (" +
                    COLUMN_PAYMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_PRODUCT_ID + " INTEGER, " +
                    COLUMN_CONTENT + " TEXT NOT NULL, " +
                    COLUMN_PAYMENT_QUANTITY + " INTEGER NOT NULL, " +
                    COLUMN_DATE + " TEXT NOT NULL, " +
                    COLUMN_PRICE + " REAL NOT NULL, " +
                    "FOREIGN KEY (" + COLUMN_PRODUCT_ID + ") REFERENCES " + TABLE_PRODUCT + "(" + COLUMN_ID + "));";

    private static final String CREATE_TABLE_UNIT =
            "CREATE TABLE " + TABLE_UNIT + " (" +
                    COLUMN_UNIT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_UNIT_NAME + " TEXT NOT NULL, " +
                    COLUMN_UNIT_DESCRIPTION + " TEXT);";

    private static final String CREATE_TABLE_WAREHOUSE =
            "CREATE TABLE " + TABLE_WAREHOUSE + " (" +
                    COLUMN_WAREHOUSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WAREHOUSE_NAME + " TEXT NOT NULL, " +
                    COLUMN_WAREHOUSE_LOCATION + " TEXT NOT NULL);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_PRODUCT);
        db.execSQL(CREATE_TABLE_PAYMENT);
        db.execSQL(CREATE_TABLE_UNIT);
        db.execSQL(CREATE_TABLE_WAREHOUSE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PAYMENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_UNIT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WAREHOUSE);
        onCreate(db);
    }
}
