package com.example.quanlykhosua.ui.milk;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.data.Product;
import com.example.quanlykhosua.ui.home.ProductAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MilkFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private DatabaseHelper databaseHelper;
    private FloatingActionButton btnAddProduct;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.milk_fragment, container, false);

        recyclerView = root.findViewById(R.id.milkRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        btnAddProduct = root.findViewById(R.id.btnThemSua);
        btnAddProduct.setOnClickListener(v -> showAddProductDialog());

        databaseHelper = new DatabaseHelper(getContext());
        loadProductData();

        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.action_milk_to_home);
                return true;
            }
            return false;
        });

        return root;
    }

    private void showAddProductDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_product, null);
        EditText etProductCode = dialogView.findViewById(R.id.etMaSP);
        EditText etProductName = dialogView.findViewById(R.id.etTenSP);
        EditText etProductQuantity = dialogView.findViewById(R.id.etSoLuong);
//        EditText etProductUnit = dialogView.findViewById(R.id.etDonVi);
        Spinner spProductUnit = dialogView.findViewById(R.id.spDonVi);
        EditText etProductWarehouse = dialogView.findViewById(R.id.etKho);

        List<String> unitList = loadUnitData();
        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, unitList);
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProductUnit.setAdapter(unitAdapter);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(dialogView)
                .setTitle("Thêm Sản Phẩm")
                .setPositiveButton("Thêm", (dialog, which) -> {
                    String productCode = etProductCode.getText().toString().trim();
                    String productName = etProductName.getText().toString().trim();
                    String productQuantity = etProductQuantity.getText().toString().trim();
                    String productUnit = spProductUnit.getSelectedItem().toString();
                    String productWarehouse = etProductWarehouse.getText().toString().trim();

                    if (productName.isEmpty() || productQuantity.isEmpty() || productUnit.isEmpty() || productWarehouse.isEmpty()) {
                        Toast.makeText(getContext(), "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    SQLiteDatabase db = databaseHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put(DatabaseHelper.COLUMN_CODE, productCode);
                    values.put(DatabaseHelper.COLUMN_NAME, productName);
                    values.put(DatabaseHelper.COLUMN_QUANTITY, Integer.parseInt(productQuantity));
                    values.put(DatabaseHelper.COLUMN_UNIT, productUnit);
                    values.put(DatabaseHelper.COLUMN_WAREHOUSE, productWarehouse);

                    long result = db.insert(DatabaseHelper.TABLE_PRODUCT, null, values);

                    if (result != -1) {
                        Toast.makeText(getContext(), "Thêm sản phẩm thành công!", Toast.LENGTH_SHORT).show();
                        loadProductData();
                    } else {
                        Toast.makeText(getContext(), "Thêm sản phẩm thất bại!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", (dialog, which) -> dialog.dismiss())
                .show();
    }
    private List<String> loadUnitData() {
        List<String> unitList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_UNIT,
                new String[]{DatabaseHelper.COLUMN_UNIT_NAME},
                null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String unitName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UNIT_NAME));
                unitList.add(unitName);
            }
            cursor.close();
        }
        return unitList;
    }
    private void loadProductData() {
        productList = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_PRODUCT,
                new String[]{
                        DatabaseHelper.COLUMN_ID,
                        DatabaseHelper.COLUMN_CODE,
                        DatabaseHelper.COLUMN_NAME,
                        DatabaseHelper.COLUMN_QUANTITY,
                        DatabaseHelper.COLUMN_UNIT,
                        DatabaseHelper.COLUMN_WAREHOUSE
                },
                null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String productCode = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CODE));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));
                String unit = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UNIT));
                String warehouse = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WAREHOUSE));

                productList.add(new Product(id, productCode, name, quantity, unit, warehouse));
            }
            cursor.close();
        }

        productAdapter = new ProductAdapter(productList, getContext(), databaseHelper);
        recyclerView.setAdapter(productAdapter);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}
