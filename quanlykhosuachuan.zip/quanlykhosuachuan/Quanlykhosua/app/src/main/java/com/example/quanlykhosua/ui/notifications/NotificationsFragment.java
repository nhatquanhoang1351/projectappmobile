package com.example.quanlykhosua.ui.notifications;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.quanlykhosua.R;
import com.example.quanlykhosua.data.DatabaseHelper;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class NotificationsFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private BarChart barChartImport, barChartExport;
    private Spinner dateSpinner;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        Log.d("NotificationsFragment", "onCreateView: Bắt đầu khởi tạo view.");

        dbHelper = new DatabaseHelper(requireContext());
        db = dbHelper.getReadableDatabase();

        Log.d("NotificationsFragment", "onCreateView: Đã kết nối với database.");

        barChartImport = root.findViewById(R.id.barChart1);
        barChartExport = root.findViewById(R.id.barChart2);
        dateSpinner = root.findViewById(R.id.dateSpinner);

        setupDateSpinner();
        return root;
    }

    private void setupDateSpinner() {
        Log.d("NotificationsFragment", "setupDateSpinner: Bắt đầu khởi tạo spinner.");
        List<String> datesList = getAvailableDates();
        Log.d("NotificationsFragment", "setupDateSpinner: Dates available: " + datesList);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, datesList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dateSpinner.setAdapter(adapter);

        dateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedDate = datesList.get(position);
                Log.d("NotificationsFragment", "onItemSelected: Date selected: " + selectedDate);
                updateCharts(selectedDate);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        int currentDateIndex = datesList.indexOf(currentDate);
        Log.d("NotificationsFragment", "setupDateSpinner: Current date index: " + currentDateIndex);
        if (currentDateIndex != -1) {
            dateSpinner.setSelection(currentDateIndex);
        }
    }

    private List<String> getAvailableDates() {
        Log.d("NotificationsFragment", "getAvailableDates: Lấy danh sách ngày từ database.");
        Set<String> datesSet = new HashSet<>();
        Cursor cursor = db.rawQuery("SELECT DISTINCT substr(" + DatabaseHelper.COLUMN_DATE + ", 1, 10) as date FROM " + DatabaseHelper.TABLE_PAYMENT, null);

        if (cursor.moveToFirst()) {
            do {
                datesSet.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();

        List<String> datesList = new ArrayList<>(datesSet);
        datesList.sort((a, b) -> b.compareTo(a));
        Log.d("NotificationsFragment", "getAvailableDates: Dates found: " + datesList);
        return datesList;
    }

    private void updateCharts(String selectedMonth) {
        Log.d("NotificationsFragment", "updateCharts: Cập nhật biểu đồ cho tháng: " + selectedMonth);

        // Import Chart
        List<BarEntry> entriesImport = getProductEntriesForImport(selectedMonth);
        List<String> productNamesImport = fetchProductNamesImport(selectedMonth);

        BarDataSet dataSetImport = new BarDataSet(entriesImport, "");
        dataSetImport.setColors(generateColorPalette(productNamesImport.size()));
        dataSetImport.setValueTextColor(Color.BLACK);
        dataSetImport.setValueTextSize(10f);

        BarData barDataImport = new BarData(dataSetImport);
        barChartImport.setData(barDataImport);
        configureBarChart(barChartImport, "", productNamesImport);
        barChartImport.invalidate();

        // Export Chart
        List<BarEntry> entriesExport = getProductEntriesForExport(selectedMonth);
        List<String> productNamesExport = fetchProductNamesExport(selectedMonth);

        BarDataSet dataSetExport = new BarDataSet(entriesExport, "");
        dataSetExport.setColors(generateColorPalette(productNamesExport.size()));
        dataSetExport.setValueTextColor(Color.BLACK);
        dataSetExport.setValueTextSize(10f);

        BarData barDataExport = new BarData(dataSetExport);
        barChartExport.setData(barDataExport);
        configureBarChart(barChartExport, "", productNamesExport);
        barChartExport.invalidate();
    }

    private List<BarEntry> getProductEntriesForImport(String selectedDate) {
        List<BarEntry> entries = new ArrayList<>();

        Cursor cursor = db.rawQuery(
                "SELECT p." + DatabaseHelper.COLUMN_NAME + ", SUM(pay." + DatabaseHelper.COLUMN_PAYMENT_QUANTITY + ") as total_quantity " +
                        "FROM " + DatabaseHelper.TABLE_PAYMENT + " pay " +
                        "JOIN " + DatabaseHelper.TABLE_PRODUCT + " p ON pay." + DatabaseHelper.COLUMN_PRODUCT_ID + " = p." + DatabaseHelper.COLUMN_ID + " " +
                        "WHERE substr(pay." + DatabaseHelper.COLUMN_DATE + ", 1, 10) = ? AND pay." + DatabaseHelper.COLUMN_CONTENT + " LIKE '%1%' " +
                        "GROUP BY p." + DatabaseHelper.COLUMN_NAME,
                new String[]{selectedDate}
        );

        if (cursor.moveToFirst()) {
            int index = 0;
            do {
                int quantity = cursor.getInt(1);
                entries.add(new BarEntry(index++, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return entries;
    }

    private List<BarEntry> getProductEntriesForExport(String selectedDate) {
        List<BarEntry> entries = new ArrayList<>();

        Cursor cursor = db.rawQuery(
                "SELECT p." + DatabaseHelper.COLUMN_NAME + ", SUM(pay." + DatabaseHelper.COLUMN_PAYMENT_QUANTITY + ") as total_quantity " +
                        "FROM " + DatabaseHelper.TABLE_PAYMENT + " pay " +
                        "JOIN " + DatabaseHelper.TABLE_PRODUCT + " p ON pay." + DatabaseHelper.COLUMN_PRODUCT_ID + " = p." + DatabaseHelper.COLUMN_ID + " " +
                        "WHERE substr(pay." + DatabaseHelper.COLUMN_DATE + ", 1, 10) = ? AND pay." + DatabaseHelper.COLUMN_CONTENT + " LIKE '%2%' " +
                        "GROUP BY p." + DatabaseHelper.COLUMN_NAME,
                new String[]{selectedDate}
        );

        if (cursor.moveToFirst()) {
            int index = 0;
            do {
                int quantity = cursor.getInt(1);
                entries.add(new BarEntry(index++, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return entries;
    }

    private List<String> fetchProductNamesImport(String selectedDate) {
        List<String> productNames = new ArrayList<>();
        Cursor cursor = db.rawQuery(
                "SELECT p." + DatabaseHelper.COLUMN_NAME + " " +
                        "FROM " + DatabaseHelper.TABLE_PAYMENT + " pay " +
                        "JOIN " + DatabaseHelper.TABLE_PRODUCT + " p ON pay." + DatabaseHelper.COLUMN_PRODUCT_ID + " = p." + DatabaseHelper.COLUMN_ID + " " +
                        "WHERE substr(pay." + DatabaseHelper.COLUMN_DATE + ", 1, 10) = ? AND pay." + DatabaseHelper.COLUMN_CONTENT + " LIKE '%1%' " +
                        "GROUP BY p." + DatabaseHelper.COLUMN_NAME,
                new String[]{selectedDate}
        );

        if (cursor.moveToFirst()) {
            do {
                productNames.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return productNames;
    }

    private List<String> fetchProductNamesExport(String selectedDate) {
        List<String> productNames = new ArrayList<>();
        Cursor cursor = db.rawQuery(
                "SELECT p." + DatabaseHelper.COLUMN_NAME + " " +
                        "FROM " + DatabaseHelper.TABLE_PAYMENT + " pay " +
                        "JOIN " + DatabaseHelper.TABLE_PRODUCT + " p ON pay." + DatabaseHelper.COLUMN_PRODUCT_ID + " = p." + DatabaseHelper.COLUMN_ID + " " +
                        "WHERE substr(pay." + DatabaseHelper.COLUMN_DATE + ", 1, 10) = ? AND pay." + DatabaseHelper.COLUMN_CONTENT + " LIKE '%2%' " +
                        "GROUP BY p." + DatabaseHelper.COLUMN_NAME,
                new String[]{selectedDate}
        );

        if (cursor.moveToFirst()) {
            do {
                productNames.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return productNames;
    }

    private List<Integer> generateColorPalette(int count) {
        List<Integer> colors = new ArrayList<>();
        int[] baseColors = {
                Color.rgb(63, 81, 181),   // Indigo
                Color.rgb(244, 67, 54),   // Red
                Color.rgb(76, 175, 80),   // Green
                Color.rgb(255, 152, 0),   // Orange
                Color.rgb(103, 58, 183),  // Deep Purple
                Color.rgb(33, 150, 243)   // Blue
        };

        for (int i = 0; i < count; i++) {
            colors.add(baseColors[i % baseColors.length]);
        }
        return colors;
    }

    private void configureBarChart(BarChart chart, String description, List<String> productNames) {
        chart.getDescription().setText(description);
        chart.getDescription().setTextSize(16f);
        chart.setPinchZoom(true);
        chart.setScaleEnabled(true);
        chart.setFitBars(true);
        chart.getXAxis().setEnabled(false);

        // Cấu hình Legend
        Legend legend = chart.getLegend();
        legend.setEnabled(true);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        legend.setOrientation(Legend.LegendOrientation.VERTICAL);
        legend.setDrawInside(false);
        legend.setWordWrapEnabled(true);
        legend.setTextSize(10f);

        // Nếu có tên sản phẩm, tạo mảng các màu và nhãn
        if (!productNames.isEmpty() && chart.getData() != null) {
            BarDataSet dataSet = (BarDataSet) chart.getData().getDataSetByIndex(0);

            // Tạo mảng màu
            List<Integer> colors = generateColorPalette(productNames.size());
            dataSet.setColors(colors);

            // Cập nhật Legend entries
            LegendEntry[] legendEntries = new LegendEntry[productNames.size()];
            for (int i = 0; i < productNames.size(); i++) {
                LegendEntry entry = new LegendEntry();
                entry.formColor = colors.get(i);
                entry.label = productNames.get(i);
                legendEntries[i] = entry;
            }
            legend.setCustom(legendEntries);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}