package com.example.quanlykhosua.ui.cost;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.quanlykhosua.data.DatabaseHelper;
import com.example.quanlykhosua.R;

import java.util.ArrayList;
import java.util.List;

public class CostFragment extends Fragment {

    private Spinner productSpinner;
    private TextView totalCostTextView;
    private TextView revenueTextView;
    private DatabaseHelper databaseHelper;

    public CostFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cost_fragment, container, false);

        productSpinner = view.findViewById(R.id.product_spinner);
        totalCostTextView = view.findViewById(R.id.total_cost);
        revenueTextView = view.findViewById(R.id.revenue_text);

        databaseHelper = new DatabaseHelper(getContext());

        loadProducts();

        return view;
    }

    private void loadProducts() {
        List<String> productList = new ArrayList<>();
        Cursor cursor = databaseHelper.getReadableDatabase().query(DatabaseHelper.TABLE_PRODUCT,
                new String[]{DatabaseHelper.COLUMN_NAME},
                null, null, null, null, null);
        int nameColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);

        if (nameColumnIndex == -1) {
            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            String name = cursor.getString(nameColumnIndex);
            productList.add(name);
        }
        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, productList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        productSpinner.setAdapter(adapter);

        productSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedProductName = (String) parentView.getItemAtPosition(position);
                calculateTotalCost(selectedProductName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });
    }

    private void calculateTotalCost(String productName) {
        Cursor cursor = databaseHelper.getReadableDatabase().query(DatabaseHelper.TABLE_PRODUCT,
                new String[]{DatabaseHelper.COLUMN_ID},
                DatabaseHelper.COLUMN_NAME + " = ?",
                new String[]{productName}, null, null, null);

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") int productId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));

            Cursor paymentCursor = databaseHelper.getReadableDatabase().query(DatabaseHelper.TABLE_PAYMENT,
                    new String[]{DatabaseHelper.COLUMN_PAYMENT_QUANTITY, DatabaseHelper.COLUMN_PRICE, DatabaseHelper.COLUMN_CONTENT},
                    DatabaseHelper.COLUMN_PRODUCT_ID + " = ?",
                    new String[]{String.valueOf(productId)}, null, null, null);

            double totalCost = 0;
            double totalRevenue = 0;

            int quantityColumnIndex = paymentCursor.getColumnIndex(DatabaseHelper.COLUMN_PAYMENT_QUANTITY);
            int priceColumnIndex = paymentCursor.getColumnIndex(DatabaseHelper.COLUMN_PRICE);
            int contentColumnIndex = paymentCursor.getColumnIndex(DatabaseHelper.COLUMN_CONTENT);

            if (quantityColumnIndex == -1 || priceColumnIndex == -1 || contentColumnIndex == -1) {
                totalCostTextView.setText("Lỗi dữ liệu: Không tìm thấy cột cần thiết trong bảng thanh toán.");
                paymentCursor.close();
                return;
            }

            while (paymentCursor.moveToNext()) {
                int quantity = paymentCursor.getInt(quantityColumnIndex);
                double price = paymentCursor.getDouble(priceColumnIndex);
                String content = paymentCursor.getString(contentColumnIndex);

                if ("1".equals(content)) {
                    totalCost += quantity * price;
                } else if ("2".equals(content)) {
                    totalRevenue += quantity * price;
                }
            }
            paymentCursor.close();

            totalCostTextView.setText("Chi phí nhập hàng: " + totalCost);
            revenueTextView.setText("Doanh thu bán được: " + totalRevenue);
        } else {
            totalCostTextView.setText("Không tìm thấy sản phẩm.");
            revenueTextView.setText("Không tìm thấy doanh thu.");
        }

        cursor.close();
    }
}
